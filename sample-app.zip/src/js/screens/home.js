import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';


import Box from 'grommet/components/Box';
import CheckBox from 'grommet/components/CheckBox';
import DateTime from 'grommet/components/DateTime';
import FormField from 'grommet/components/FormField';
import Form from 'grommet/components/Form';
import TextInput from 'grommet/components/TextInput';
import Heading from 'grommet/components/Heading';
import Select from 'grommet/components/Select';
import SearchInput from 'grommet/components/SearchInput';
import Title from 'grommet/components/Title';


class home extends Component {

constructor() {
    super();
   
  }

  render() {
    console.log("===Home=========");
    return (
      
        <Box justify='start' align='start' wrap={true} pad='small' margin='large' align='center' >
              <Heading strong={true} uppercase={false} truncate={false}> Sample Heading</Heading>

             <Box direction='row' pad='small'>
                  <TextInput/>
                  <TextInput/>
                  <TextInput/>
                  <TextInput/>
                  <TextInput/>
             </Box>

             <Box direction='row' pad='small'>
                  <DateTime id='id' name='name' format='D/M/YYYY'/>
                  <Select placeHolder='Select' inline={false} options={['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight']} value={undefined} />
                  <SearchInput placeHolder='Search'/>
                  <CheckBox label='Sample label' toggle={true} disabled={false} reverse={false} />
                  <CheckBox label='Sample label' toggle={false} disabled={false} reverse={false} />
             </Box>

             <Title>Date Registered</Title>
              <Box direction="column" align="start">
                <CheckBox id="Week" name="Week" key="Week" value="Week" label="Week"/>
                <CheckBox id="30Days" name="30Days" key="30Days" value="30Days" label="30 Days"/>
                <CheckBox id="60Days" name="60Days" key="60Days" value="60Days" label="60 Days"/>
                <CheckBox id="90Days" name="90Days" key="90Days" value="90Days" label="90 Days"/>
              </Box>

              </Box>
   
  

 );
  }
}

home.propTypes = {
  dispatch: PropTypes.func.isRequired,
  error: PropTypes.object,
  tasks: PropTypes.arrayOf(PropTypes.object)
};

home.contextTypes = {
  intl: PropTypes.object
};

const select = state => ({ ...state.home });

export default connect(select)(home);
